import { Button } from "@/components/ui/button"
import Link from "next/link"

export default function About() {
  return (
    <div className="space-y-8">
      <div className="text-center">
        <h1 className="text-4xl font-bold mb-4">About AI Platform</h1>
        <p className="text-xl text-gray-600">Empowering innovation through cutting-edge AI technology</p>
      </div>
      <div className="prose prose-lg mx-auto">
        <p>
          AI Platform is at the forefront of artificial intelligence innovation, providing state-of-the-art tools and
          services to businesses and individuals alike. Our mission is to make AI technology accessible, user-friendly,
          and powerful enough to transform industries.
        </p>
        <p>
          Founded in 2023, our team of expert data scientists, engineers, and designers work tirelessly to develop and
          refine our AI models, ensuring they deliver accurate, efficient, and valuable results for our users.
        </p>
        <h2>Our Technology</h2>
        <p>
          We leverage the latest advancements in machine learning, natural language processing, and computer vision to
          power our suite of AI tools. Our technology stack includes:
        </p>
        <ul>
          <li>Advanced neural networks for text-to-speech conversion</li>
          <li>State-of-the-art image generation models</li>
          <li>Robust language models for content generation and analysis</li>
          <li>Cutting-edge computer vision algorithms for image recognition and processing</li>
        </ul>
        <h2>Our Commitment</h2>
        <p>At AI Platform, we are committed to:</p>
        <ul>
          <li>Continuous innovation and improvement of our AI models</li>
          <li>Ensuring the privacy and security of our users' data</li>
          <li>Providing excellent customer support and guidance</li>
          <li>Promoting responsible and ethical use of AI technology</li>
        </ul>
      </div>
      <div className="text-center">
        <Link href="/signup">
          <Button size="lg">Join AI Platform Today</Button>
        </Link>
      </div>
    </div>
  )
}

