export default function Head() {
  return (
    <>
      <title>AI Platform - Your Hub for AI-Powered Tools and Services</title>
      <meta content="width=device-width, initial-scale=1" name="viewport" />
      <meta
        name="description"
        content="Discover the power of AI with our cutting-edge tools and services. Transform text to speech, generate images, and more with AI Platform."
      />
      <link rel="icon" href="/favicon.ico" />
    </>
  )
}

