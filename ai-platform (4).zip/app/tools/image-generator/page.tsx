"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { useToast } from "@/components/ui/use-toast"

export default function ImageGenerator() {
  const [prompt, setPrompt] = useState("")
  const [isLoading, setIsLoading] = useState(false)
  const [generatedImage, setGeneratedImage] = useState<string | null>(null)
  const { toast } = useToast()

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    setIsLoading(true)

    // Here you would typically call your AI service API
    // For this example, we'll just simulate a delay and use a placeholder image
    await new Promise((resolve) => setTimeout(resolve, 2000))
    setGeneratedImage("/placeholder.svg?height=512&width=512")

    setIsLoading(false)
    toast({
      title: "Image generated",
      description: "Your AI-generated image is ready!",
    })
  }

  return (
    <div className="space-y-8">
      <div className="text-center">
        <h1 className="text-4xl font-bold mb-4">AI Image Generator</h1>
        <p className="text-xl text-gray-600">Create unique images from text prompts using our advanced AI</p>
      </div>
      <form onSubmit={handleSubmit} className="space-y-4">
        <div>
          <Label htmlFor="prompt">Image Prompt</Label>
          <Input
            id="prompt"
            value={prompt}
            onChange={(e) => setPrompt(e.target.value)}
            placeholder="Describe the image you want to generate..."
            required
          />
        </div>
        <Button type="submit" disabled={isLoading || !prompt}>
          {isLoading ? "Generating..." : "Generate Image"}
        </Button>
      </form>
      {generatedImage && (
        <div className="mt-8">
          <h2 className="text-2xl font-semibold mb-4">Generated Image</h2>
          <img
            src={generatedImage || "/placeholder.svg"}
            alt="AI-generated image"
            className="max-w-full h-auto rounded-lg shadow-md"
          />
        </div>
      )}
    </div>
  )
}

