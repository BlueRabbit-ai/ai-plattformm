"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Textarea } from "@/components/ui/textarea"
import { useToast } from "@/components/ui/use-toast"

export default function TextToSpeech() {
  const [text, setText] = useState("")
  const [isLoading, setIsLoading] = useState(false)
  const { toast } = useToast()

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    setIsLoading(true)

    // Here you would typically call your AI service API
    // For this example, we'll just simulate a delay
    await new Promise((resolve) => setTimeout(resolve, 2000))

    setIsLoading(false)
    toast({
      title: "Text converted to speech",
      description: "Your audio file is ready for download.",
    })
  }

  return (
    <div className="space-y-8">
      <div className="text-center">
        <h1 className="text-4xl font-bold mb-4">Text-to-Speech Converter</h1>
        <p className="text-xl text-gray-600">Transform your text into natural-sounding speech</p>
      </div>
      <form onSubmit={handleSubmit} className="space-y-4">
        <Textarea
          placeholder="Enter your text here..."
          value={text}
          onChange={(e) => setText(e.target.value)}
          rows={5}
          className="w-full"
        />
        <Button type="submit" disabled={isLoading || !text}>
          {isLoading ? "Converting..." : "Convert to Speech"}
        </Button>
      </form>
    </div>
  )
}

