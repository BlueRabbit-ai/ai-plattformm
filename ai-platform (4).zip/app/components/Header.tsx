"use client"

import { useState } from "react"
import Link from "next/link"
import { Button } from "@/components/ui/button"
import { Menu, X } from "lucide-react"

export default function Header() {
  const [isMenuOpen, setIsMenuOpen] = useState(false)

  return (
    <header className="bg-white shadow-md">
      <div className="container mx-auto px-4 py-4">
        <div className="flex justify-between items-center">
          <Link href="/" className="text-2xl font-bold">
            AI Platform
          </Link>
          <nav className="hidden md:block">
            <ul className="flex space-x-4">
              <li>
                <Link href="/tools" className="text-gray-600 hover:text-gray-900">
                  Tools
                </Link>
              </li>
              <li>
                <Link href="/pricing" className="text-gray-600 hover:text-gray-900">
                  Pricing
                </Link>
              </li>
              <li>
                <Link href="/login">
                  <Button variant="outline">Login</Button>
                </Link>
              </li>
              <li>
                <Link href="/signup">
                  <Button>Sign Up</Button>
                </Link>
              </li>
            </ul>
          </nav>
          <button className="md:hidden" onClick={() => setIsMenuOpen(!isMenuOpen)}>
            {isMenuOpen ? <X /> : <Menu />}
          </button>
        </div>
        {isMenuOpen && (
          <nav className="mt-4 md:hidden">
            <ul className="space-y-2">
              <li>
                <Link href="/tools" className="block py-2 text-gray-600 hover:text-gray-900">
                  Tools
                </Link>
              </li>
              <li>
                <Link href="/pricing" className="block py-2 text-gray-600 hover:text-gray-900">
                  Pricing
                </Link>
              </li>
              <li>
                <Link href="/login" className="block py-2">
                  <Button variant="outline" className="w-full">
                    Login
                  </Button>
                </Link>
              </li>
              <li>
                <Link href="/signup" className="block py-2">
                  <Button className="w-full">Sign Up</Button>
                </Link>
              </li>
            </ul>
          </nav>
        )}
      </div>
    </header>
  )
}

