"use client"

import { useState, useEffect } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Progress } from "@/components/ui/progress"

export default function Dashboard() {
  const [usage, setUsage] = useState({
    textToSpeech: 0,
    imageGeneration: 0,
  })

  useEffect(() => {
    // Simulating API call to fetch user usage data
    const fetchUsage = async () => {
      // In a real application, you would fetch this data from your backend
      setUsage({
        textToSpeech: 75,
        imageGeneration: 40,
      })
    }

    fetchUsage()
  }, [])

  return (
    <div className="space-y-8">
      <div className="text-center">
        <h1 className="text-4xl font-bold mb-4">Your Dashboard</h1>
        <p className="text-xl text-gray-600">Monitor your AI tool usage and account details</p>
      </div>
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        <Card>
          <CardHeader>
            <CardTitle>Text-to-Speech Usage</CardTitle>
          </CardHeader>
          <CardContent>
            <Progress value={usage.textToSpeech} className="mb-2" />
            <p className="text-sm text-gray-600">{usage.textToSpeech}% of monthly limit used</p>
          </CardContent>
        </Card>
        <Card>
          <CardHeader>
            <CardTitle>Image Generation Usage</CardTitle>
          </CardHeader>
          <CardContent>
            <Progress value={usage.imageGeneration} className="mb-2" />
            <p className="text-sm text-gray-600">{usage.imageGeneration}% of monthly limit used</p>
          </CardContent>
        </Card>
      </div>
      <div className="flex justify-center">
        <Button>Upgrade Plan</Button>
      </div>
    </div>
  )
}

