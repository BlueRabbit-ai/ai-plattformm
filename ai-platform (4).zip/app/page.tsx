import { Suspense } from "react"
import Link from "next/link"
import { Button } from "@/components/ui/button"
import OptimizedImage from "@/components/OptimizedImage"

export default function Home() {
  return (
    <div className="space-y-16">
      <section className="text-center">
        <h1 className="text-4xl font-bold mb-6">Welcome to AI Platform</h1>
        <p className="text-xl mb-8 text-gray-600">Discover the power of AI with our cutting-edge tools and services.</p>
        <Link href="/signup">
          <Button size="lg">Get Started</Button>
        </Link>
      </section>

      <section>
        <h2 className="text-3xl font-semibold mb-8 text-center">Our AI Tools</h2>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
          <div className="bg-white p-6 rounded-lg shadow-md">
            <h3 className="text-2xl font-semibold mb-4">Text-to-Speech Converter</h3>
            <p className="mb-4 text-gray-600">
              Transform your text into natural-sounding speech with our advanced AI technology.
            </p>
            <Link href="/tools/text-to-speech">
              <Button variant="outline">Try it now</Button>
            </Link>
          </div>
          <div className="bg-white p-6 rounded-lg shadow-md">
            <h3 className="text-2xl font-semibold mb-4">AI Image Generator</h3>
            <p className="mb-4 text-gray-600">
              Create stunning, unique images from text prompts using state-of-the-art AI models.
            </p>
            <Link href="/tools/image-generator">
              <Button variant="outline">Try it now</Button>
            </Link>
          </div>
        </div>
      </section>

      <Suspense fallback={<div>Loading...</div>}>
        <section className="text-center">
          <h2 className="text-3xl font-semibold mb-6">See AI in Action</h2>
          <div className="max-w-2xl mx-auto">
            <OptimizedImage src="/ai-demo.jpg" alt="AI Platform Demo" width={800} height={450} />
          </div>
        </section>
      </Suspense>

      <section className="text-center">
        <h2 className="text-3xl font-semibold mb-6">Ready to get started?</h2>
        <p className="text-xl mb-8 text-gray-600">Join thousands of users leveraging the power of AI today.</p>
        <Link href="/signup">
          <Button size="lg">Sign Up Now</Button>
        </Link>
      </section>
    </div>
  )
}

