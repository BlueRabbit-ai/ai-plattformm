import Link from "next/link"
import { Button } from "@/components/ui/button"
import { Check } from "lucide-react"

const plans = [
  {
    name: "Free",
    price: "$0",
    features: ["Basic access to AI tools", "Limited usage (100 requests/month)", "Community support"],
    cta: "Get Started",
    href: "/signup",
  },
  {
    name: "Pro",
    price: "$19.99",
    features: [
      "Full access to AI tools",
      "Higher usage limits (1000 requests/month)",
      "Priority support",
      "Advanced analytics",
    ],
    cta: "Upgrade to Pro",
    href: "/signup?plan=pro",
  },
  {
    name: "Enterprise",
    price: "Custom",
    features: [
      "Unlimited access",
      "Custom usage limits",
      "Dedicated support",
      "Custom integrations",
      "On-premise deployment options",
    ],
    cta: "Contact Sales",
    href: "/contact",
  },
]

export default function Pricing() {
  return (
    <div className="space-y-8">
      <div className="text-center">
        <h1 className="text-4xl font-bold mb-4">Choose Your Plan</h1>
        <p className="text-xl text-gray-600">Select the perfect plan for your AI needs</p>
      </div>
      <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
        {plans.map((plan) => (
          <div key={plan.name} className="bg-white p-8 rounded-lg shadow-md flex flex-col">
            <h2 className="text-2xl font-semibold mb-4">{plan.name}</h2>
            <p className="text-4xl font-bold mb-6">{plan.price}</p>
            <ul className="mb-8 space-y-4 flex-grow">
              {plan.features.map((feature) => (
                <li key={feature} className="flex items-start">
                  <Check className="w-5 h-5 mr-2 text-green-500 flex-shrink-0" />
                  <span>{feature}</span>
                </li>
              ))}
            </ul>
            <Link href={plan.href}>
              <Button className="w-full">{plan.cta}</Button>
            </Link>
          </div>
        ))}
      </div>
    </div>
  )
}

