import { NextSeo } from "next-seo"

interface StructuredDataProps {
  title: string
  description: string
  url: string
}

export default function StructuredData({ title, description, url }: StructuredDataProps) {
  const structuredData = {
    "@context": "https://schema.org",
    "@type": "WebSite",
    name: title,
    description: description,
    url: url,
  }

  return (
    <NextSeo
      title={title}
      description={description}
      canonical={url}
      openGraph={{
        url,
        title,
        description,
      }}
      additionalMetaTags={[
        {
          name: "application-name",
          content: "AI Platform",
        },
        {
          name: "apple-mobile-web-app-capable",
          content: "yes",
        },
        {
          name: "apple-mobile-web-app-status-bar-style",
          content: "default",
        },
        {
          name: "apple-mobile-web-app-title",
          content: "AI Platform",
        },
        {
          name: "format-detection",
          content: "telephone=no",
        },
        {
          name: "mobile-web-app-capable",
          content: "yes",
        },
      ]}
    />
  )
}

