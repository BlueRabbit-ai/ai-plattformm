import { useState, useEffect } from "react"
import { useTranslation } from "next-i18next"

export default function Layout({ children }) {
  const [isMobile, setIsMobile] = useState(false)
  const { t } = useTranslation("common")

  useEffect(() => {
    const handleResize = () => setIsMobile(window.innerWidth < 768)
    handleResize()
    window.addEventListener("resize", handleResize)
    return () => window.removeEventListener("resize", handleResize)
  }, [])

  return (
    <div className={`container mx-auto px-4 ${isMobile ? "py-4" : "py-8"}`}>
      <header className={isMobile ? "text-center" : "flex justify-between items-center"}>
        <h1 className="text-2xl font-bold">{t("welcome")}</h1>
        <nav className={isMobile ? "mt-4" : ""}>{/* Navigation items */}</nav>
      </header>
      <main className="mt-8">{children}</main>
    </div>
  )
}

