import dynamic from "next/dynamic"
import { Suspense } from "react"

interface LazyComponentProps {
  component: () => Promise<React.ComponentType<any>>
  fallback?: React.ReactNode
}

export default function LazyComponent({ component, fallback = null }: LazyComponentProps) {
  const DynamicComponent = dynamic(component, {
    suspense: true,
  })

  return (
    <Suspense fallback={fallback}>
      <DynamicComponent />
    </Suspense>
  )
}

