import { useState, useEffect, useRef } from "react"
import Image from "next/image"

export default function LazyImage({ src, alt, width, height }) {
  const [isIntersecting, setIntersecting] = useState(false)
  const ref = useRef()

  useEffect(() => {
    const observer = new IntersectionObserver(([entry]) => {
      if (entry.isIntersecting) {
        setIntersecting(true)
        observer.unobserve(entry.target)
      }
    })

    if (ref.current) {
      observer.observe(ref.current)
    }

    return () => {
      if (ref.current) {
        observer.unobserve(ref.current)
      }
    }
  }, [])

  return (
    <div ref={ref}>
      {isIntersecting ? (
        <Image src={src || "/placeholder.svg"} alt={alt} width={width} height={height} loading="lazy" />
      ) : (
        <div style={{ width, height, backgroundColor: "#f0f0f0" }} />
      )}
    </div>
  )
}

